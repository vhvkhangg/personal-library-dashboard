import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Picture" description="Photos and picture metadata." domainColumn="Shot Location" domainValue="Unknown" mediaPreview="picture" />;
}
