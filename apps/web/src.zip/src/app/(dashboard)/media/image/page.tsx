import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return (
    <ModuleLandingPage
      title="Image"
      description="Image collections and viewing workflow."
      domainColumn="Format"
      domainValue="Image"
      mediaPreview="image"
    />
  );
}
