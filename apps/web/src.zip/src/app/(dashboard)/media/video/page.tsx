import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return (
    <ModuleLandingPage
      title="Video"
      description="Videos and playback progress."
      domainColumn="Duration"
      domainValue="Unknown"
      mediaPreview="video"
    />
  );
}
