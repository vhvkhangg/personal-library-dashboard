import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return (
    <ModuleLandingPage
      title="Illustrator"
      description="Illustrators and their platforms."
      domainColumn="Platform"
      domainValue="Unknown"
    />
  );
}
