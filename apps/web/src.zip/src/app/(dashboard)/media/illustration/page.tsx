import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Illustration" description="Illustrations and character art." domainColumn="Character" domainValue="Unknown" mediaPreview="illustration" />;
}
