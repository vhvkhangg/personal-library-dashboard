import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Account" description="Social accounts and creators you follow across platforms." domainColumn="Platform" domainValue="YouTube" typeColumnLabel="Account Type" typeValue="Creator" mediaPreview="account" />;
}
