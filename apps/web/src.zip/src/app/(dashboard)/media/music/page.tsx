import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Music" description="Music library and listening progress." domainColumn="Artist" domainValue="Aurora Lane" mediaPreview="music" />;
}
