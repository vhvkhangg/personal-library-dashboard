import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Media" description="Images, videos, music, illustrators, and musicians." domainColumn="Format" showAnalytics />;
}
