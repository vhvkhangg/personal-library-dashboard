import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return (
    <ModuleLandingPage
      title="Musician"
      description="Musicians and their platforms."
      domainColumn="Platform"
      domainValue="Unknown"
    />
  );
}
