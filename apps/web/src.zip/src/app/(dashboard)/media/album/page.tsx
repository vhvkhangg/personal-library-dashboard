import { ModuleLandingPage } from "@/components/dashboard/module-landing-page";

export default function Page() {
  return <ModuleLandingPage title="Album" description="Albums that can group image, picture, and illustration items." domainColumn="Collection" domainValue="Mixed media" mediaPreview="album" />;
}
