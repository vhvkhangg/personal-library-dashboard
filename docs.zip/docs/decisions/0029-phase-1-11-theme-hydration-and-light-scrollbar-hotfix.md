# 0029 — Phase 1.11 theme hydration and light scrollbar hotfix

## Status
Accepted

## Context

The theme toggle produced a React hydration mismatch because the server-rendered icon and accessible labels could differ from the client-rendered icon after reading the persisted theme.

The light-mode page scrollbar also needed stronger contrast.

## Changes

- Made `ThemeToggle` render stable server/client markup.
- Changed the theme button accessible label and title to the static value `Toggle theme`.
- Rendered both Sun and Moon icons and switched visibility through CSS instead of branching on the client theme during hydration.
- Kept the icon behavior:
  - Light mode shows the Moon icon.
  - Dark mode shows the Sun icon.
- Darkened light-mode scrollbar track and thumb colors for stronger contrast.

## Consequences

The theme button no longer changes its server/client HTML during hydration, so it avoids the recoverable React mismatch. The page scrollbar is easier to see in light mode.
