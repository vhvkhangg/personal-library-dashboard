# 0026 — Phase 1.11 tooling, shell alignment, and light-mode polish

## Status
Accepted

## Context
This follow-up patch addresses a small set of UI and developer-tooling issues found after the previous Phase 1.11 patch. The requested changes are intentionally narrow: fix TypeScript/ESLint configuration errors, align the shell separators, improve the PIN modal position, make light-mode scrollbars and status badges more visible, and keep module descriptions visible under each module title.

## Changes

- Add `ignoreDeprecations: "6.0"` to the web TypeScript config so TypeScript stops failing on the deprecated `baseUrl` option while the project still uses the existing alias setup.
- Replace the ESLint flat config with the non-`FlatCompat` Next.js config imports to avoid the circular JSON structure error in ESLint 9.
- Align the module-sidebar heading with the header search row.
- Add a full-height vertical separator at the boundary between the module sidebar and header/content area.
- Keep the header horizontal separator spanning from the icon sidebar boundary across the content area.
- Center the protected PIN modal using a full-viewport grid overlay and move the `PIN code` label slightly upward.
- Darken light-mode scrollbars for better visibility.
- Strengthen light-mode status badge backgrounds and borders.
- Preserve visible module descriptions under module titles.

## Runtime note

The messages below are development-cache warnings from the Next/Turbopack dev server, not application logic errors:

```txt
Persisting failed: Another write batch or compaction is already active
Compaction failed: Another write batch or compaction is already active
```

If they continue, stop duplicate dev servers, delete `apps/web/.next`, then restart the frontend. This patch does not add application code for that warning because it originates from the local dev-server cache writer.
