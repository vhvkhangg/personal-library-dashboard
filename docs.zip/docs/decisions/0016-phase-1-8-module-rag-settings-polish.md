# ADR 0016 — Phase 1.8 Module, RAG, Settings, and Modal Polish

## Status
Accepted

## Context
The phase-1 shell needed another visual polish round after review. Key issues included over-generic columns, too-simple details, missing tag-management affordances, incomplete RAG workspace affordances, and generic chart samples.

## Decision
We will implement a UI-only patch that:
- supports hiding table domain columns by module,
- adds module tag panels,
- changes item forms to choose existing tags only,
- enriches detail/edit/new item modal samples,
- adds chart varieties without bringing in a charting dependency,
- adds media preview panels for relevant modules,
- improves RAG workspace upload and benchmark affordances,
- moves RAG-specific tuning back out of Settings.

## Consequences
### Positive
- The phase-1 shell better demonstrates the target UX.
- Module-specific table configuration becomes clearer.
- RAG and media surfaces are easier to evaluate visually.
- Settings is cleaner and less duplicated.

### Negative
- Placeholder UI complexity increases before real data binding.
