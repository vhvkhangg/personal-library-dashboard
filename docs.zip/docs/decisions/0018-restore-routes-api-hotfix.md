# 0018 — Restore routes API after Phase 1.9

## Status
Accepted

## Decision
Keep the existing layout route API stable for Phase 1 and restore `primaryNavigation`, `systemNavigation`, and menu helper exports.

## Consequences

- `IconSidebar`, `MenuSidebar`, and `AppShell` can build again.
- The Media sidebar keeps the Phase 1.9 decision to merge Song into Music by removing the Song menu item.
