# 0009 — UI Shell Refinement for Phase 1.1

## Status

Accepted

## Context

After Phase 1 scaffold, the UI rendered successfully but the table and dashboard were too skeletal. The user requested table headers, rows-per-page selection, favorite marking, a better shortcut label, light/dark toggle, Settings separation, dashboard panels, and clearer active navigation state.

These changes should happen before auth and data integration because layout-level changes are cheaper at this stage.

## Decision

Refine the UI shell in Phase 1.1.

Table/list pages use the following generic columns:

```txt
Favorite + # | Item | Type | Tag | Updated | Rating | Actions
```

Rows-per-page options:

```txt
10 / 20 / 30 / 40 / 50
```

Header changes:

- display `Ctrl + K`
- add icon-only light/dark toggle beside the NSFW `H` button

Navigation changes:

- keep content modules under `Library`
- move `Settings` under `System`
- keep `Settings` at the bottom of the icon sidebar
- show clear active state for the current route

Global dashboard panels:

- summary cards
- items by module
- rating distribution
- recent updates
- storage overview
- top tags

## Alternatives Considered

### Keep the scaffold UI unchanged

Rejected because the table and dashboard looked too empty and did not yet match the intended dashboard style.

### Add dense dashboard analytics immediately

Rejected for Phase 1.1 because real data does not exist yet. Dense analytics should wait until items, tags, storage, and RAG data exist.

### Add module-specific table columns now

Rejected for the generic table shell. Module-specific columns such as Fiction `World Setting` should be added when each module gets real data models.

## Consequences

Positive:

- The app looks closer to the intended product earlier.
- The generic table/list pattern is more stable before data integration.
- Settings is visually separated from content modules.
- Theme mode can be evaluated early.

Tradeoffs:

- Table rows still use placeholder data.
- Favorite, pagination, and filters are visual only until later phases.
- Dashboard charts are lightweight mock panels rather than real charting library components.

## Follow-ups

- Connect table shell to API data after auth and tags exist.
- Add module-specific columns later.
- Decide whether to introduce a full charting library when real dashboard analytics exist.
- Add real command palette behavior after global search design is implemented.
