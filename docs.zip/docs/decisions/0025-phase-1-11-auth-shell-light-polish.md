# 0025 — Phase 1.11 auth shell, protected modal, and light-mode polish

## Status
Accepted

## Context
The follow-up review requested small, targeted UI corrections only. The scope remains UI-only and does not introduce real authentication, persistence, or backend behavior.

## Changes

- Update the login form:
  - replace the username/email/phone mail icon with a user icon,
  - add a key icon inside the password field.
- Keep the `/login` route as a UI preview for future JWT/local-only authentication.
- Center the protected PIN modal through a body-level portal so the overlay covers the whole screen consistently.
- Extend shell separator lines:
  - the vertical separator reaches the top of the viewport,
  - the horizontal separator starts from the boundary between the icon sidebar and the module sidebar.
- Improve light-mode scrollbars across module pages and modal scroll areas.
- Strengthen light-mode status badges/dropdowns so Active, Draft, and Archived are more readable.
- Restore the module description line under each module title.
- Add explicit metadata for the app icon.

## Runtime note

The messages below are development-cache warnings from the Next.js/Turbopack dev server, not application logic errors:

```txt
Persisting failed: Another write batch or compaction is already active (Only a single write operations is allowed at a time)
Compaction failed: Another write batch or compaction is already active (Only a single write operations is allowed at a time)
```

They usually happen when the dev cache is being written/compacted while another dev-server operation is active, especially on Windows or when multiple dev commands are running. The practical recovery path is to stop duplicate dev servers, delete `apps/web/.next`, then restart `pnpm --filter @pld/web dev`.
