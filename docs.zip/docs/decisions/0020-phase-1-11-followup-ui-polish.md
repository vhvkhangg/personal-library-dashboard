# 0020 — Phase 1.11 follow-up UI polish

## Status
Accepted

## Context

A follow-up review of the Phase 1.11 dashboard surfaced a second batch of UX refinements: the RAG sidebars needed to be grouped into cleaner left/right frames, Ideaverse needed a collapsible `Core` navigation group, module headers still showed extra helper copy, date filters needed a single shared visual pattern, and Media needed an `Album` module with its own viewer preview.

## Decision

Apply a second Phase 1.11 refinement pass that preserves the UI-only architecture while normalizing repeated layout patterns across modules.

## Changes

- Group `Chats` and `Uploaded documents` inside one left-side RAG workspace frame.
- Group `Citation` and `Benchmark` inside one right-side inspector frame.
- Keep `RAG settings` compact and centered above the chat area.
- Remove module-header helper paragraphs from Ideaverse and dashboard module landing pages.
- Replace the new-tag modal `Close` text button with an `X` dismiss control.
- Standardize the two date filter inputs to the shared `mm/dd/yyyy` placeholder appearance across modules.
- Convert the Ideaverse sidebar `Core` entry into a collapsible dropdown that reveals the child sections below it.
- Add a Media `Album` module and an album viewer preview that can represent mixed image, picture, and illustration collections.
- Replace image zoom `+ / -` controls with a dropdown-based zoom selector.
- Raise the row-action menu layering and keep the `View details` action visible.

## Consequences

- Module pages look more uniform and less text-heavy.
- The RAG workspace better matches the intended three-column composition.
- Media now has a clear place for mixed collections without introducing backend behavior yet.
