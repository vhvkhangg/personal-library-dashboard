# 0018 — Phase 1.10 UI polish

## Status
Accepted

## Context

The UI shell needed another polish pass after reviewing tables, media modules, item modals, and Ideaverse pages.

## Decision

Use item tables for general library modules, but use a file-tree Markdown preview for Ideaverse submodules. Keep Dashboard pages chart-heavy, while submodule pages stay focused on concrete work surfaces.

## Consequences

- Ideaverse now communicates its Obsidian/vault-first direction more clearly.
- Table rows are more compact because descriptions sit under item names.
- Media previews have controls that better match image/video/music behavior.
