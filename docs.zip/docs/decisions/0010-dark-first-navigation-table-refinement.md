# 0010 — Dark-First Navigation and Table Refinement

## Status

Accepted

## Context

After Phase 1.1, browser testing showed several UI issues:

- table header/cell alignment was not reliable enough
- light mode had surfaces that looked unintentionally dark
- active navigation used white backgrounds that looked too blunt in dark mode
- every primary sidebar icon showed the same secondary menu
- Settings did not need a secondary menu
- RAG/Documents should also collapse the secondary menu for now
- the Next.js development indicator overlapped the bottom Settings icon

The user also requested that the project default to dark mode and polish dark mode first.

## Decision

Adopt a dark-first shell for the early UI phases.

Use the blue-violet/indigo accent as the selected/active state across navigation, tabs, badges, and pagination.

Replace the grid-based table shell with a semantic HTML table.

Make the secondary sidebar module-specific:

- Fiction gets Fiction menus.
- Film gets Film menus.
- Media gets Media menus.
- F&B gets F&B menus.
- Information gets Information menus.
- NSFW gets NSFW menus.
- Ideaverse gets Ideaverse menus.

Collapse the secondary sidebar for:

- Dashboard
- RAG/Documents
- Settings

Disable the Next.js development indicator in `next.config.ts` because it overlaps the bottom Settings icon during development.

## Alternatives Considered

### Keep grid rows for the table

Rejected because the visible browser result showed misalignment. A native table is better for tabular shell structure.

### Keep Settings inside the secondary sidebar

Rejected because Settings currently has no sub-navigation and makes the menu feel artificial.

### Move the Next.js dev indicator instead of hiding it

Rejected for this phase. Hiding the indicator is simpler and removes the conflict entirely. Runtime/build errors still appear.

### Polish dark and light equally now

Rejected for this phase. The user wants dark mode completed first. Light mode should remain usable but can be refined later.

## Consequences

Positive:

- navigation feels more intentional
- dark mode has a consistent active color
- table alignment is more stable
- content area expands when secondary menu is unnecessary
- Settings is no longer blocked by the dev indicator

Tradeoffs:

- light mode is supported but not final-polished
- module submenu routes are placeholders until module implementation phases
- RAG/Documents may need a secondary menu later after RAG UI exists

## Follow-ups

- Add real command palette behavior.
- Add route pages for all module submenu paths.
- Add real table state and pagination.
- Add module-specific columns in later module phases.
- Revisit RAG/Documents secondary menu when RAG screens are designed.
