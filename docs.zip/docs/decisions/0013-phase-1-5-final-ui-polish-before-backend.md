# ADR 0013 — Final Phase 1 UI Polish Before Backend Work

## Status
Accepted

## Context
After several review iterations, the UI shell still needed one more pass before moving into backend and auth phases. The main issues were:
- weak light-mode interaction contrast,
- awkward hover behavior,
- incomplete pagination preview,
- missing row actions menu,
- generic RAG and Settings pages that did not reflect their actual roles,
- ambiguous submenu activation on nested routes.

## Decision
We will perform a final phase-1 polish pass with the following changes:
- strengthen interactive hover states,
- make light-mode interactive content more visible,
- model table pagination and row actions in the shell,
- create dedicated RAG and Settings workspace pages,
- correct module submenu active-state logic,
- keep all new documentation under `docs/` only.

## Consequences
### Positive
- The user can validate most important UI patterns before backend work.
- RAG and Settings now communicate their true product role.
- Table interaction expectations are clearer.
- The navigation model is less confusing.

### Negative
- The shell layer contains more placeholder logic that will later be replaced by real state and API integration.
