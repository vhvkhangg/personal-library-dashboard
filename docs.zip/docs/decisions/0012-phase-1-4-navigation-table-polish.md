# ADR 0012 — Phase 1.4 Navigation and Table Polish

## Status
Accepted

## Context
The phase 1.3 shell was functionally acceptable but still had several UX issues:
- redundant repeated module labels in the menu sidebar,
- table columns with inconsistent alignment,
- a `Favorite` label that was visually too long for the narrow first column,
- placeholder rows that implied only one tag per item,
- icon assignments that felt semantically inverted for Ideaverse and RAG.

## Decision
For phase 1.4 we will:
- remove repeated section titles from the menu sidebar rendering,
- keep a single module heading at the top of the menu sidebar,
- center narrow table columns and keep the `Item` column left-aligned,
- rename the first column label from `Favorite` to `Fav`,
- render multiple tag pills in the placeholder dataset,
- swap the Ideaverse and RAG icons.

## Consequences
### Positive
- Cleaner visual hierarchy.
- Table reads more evenly.
- Placeholder UI better reflects the intended tagging model.
- Icon meanings feel closer to the module purpose.

### Negative
- Some sidebar grouping semantics are no longer visible in the UI, though the underlying route grouping remains in code.
