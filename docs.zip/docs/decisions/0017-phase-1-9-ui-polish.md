# 0017 — Phase 1.9 UI polish direction

## Status
Accepted

## Decision
Phase 1.9 emphasizes workflow clarity over new backend behavior. The UI should show how real interactions will feel by introducing mock modals, viewer panels, and more explicit table affordances.

## Consequences
- More components now contain UI-only interaction state.
- Submodule pages are visually lighter because charts are reserved for dashboards.
- Media modules better communicate intended future behavior.
- RAG workspace inspection patterns are clearer for later implementation.
