# 0022 — Phase 1.11 table, detail, RAG, and attachment polish

## Status
Accepted

## Context
The latest UI review focused on small but important interaction details that should be resolved before backend integration: editable table status, safer delete actions, avatar preview behavior, cleaner detail-modal information hierarchy, and a less dominant citation-count card in the RAG workspace.

## Decision
Apply a targeted UI-only patch with minimal file changes.

## Changes

- Add an editable `Status` dropdown in every module item table.
- Give each status its own visual treatment:
  - `Active`: green
  - `Draft`: amber
  - `Archived`: slate
- Add avatar preview behavior when clicking an item avatar in tables.
- Add delete confirmation popups for table row delete actions and RAG workspace delete actions.
- Reduce the RAG `Total cited sources` value size so it matches the label scale.
- Keep inline citation markers visually consistent with citation-source badges.
- Add per-source expand/collapse controls for citation chunks.
- Rework item detail layout:
  - `View details` is aligned directly above the item title.
  - `Summary` now includes a short summary paragraph.
  - `Status` is moved into the Summary metrics area.
  - `Facts` no longer repeats status or favorite data.
  - Facts are split into compact individual cards.
- Rework edit modal layout:
  - `Edit item` is aligned directly above the item title.
  - `Status` and `Mark as favorite` are removed from the edit form.
  - Attachment replacement now has a sample multi-attachment preview flow.

## Scope
Only UI shell behavior is changed. No backend persistence, upload logic, delete mutation, or database schema behavior is introduced in this patch.
