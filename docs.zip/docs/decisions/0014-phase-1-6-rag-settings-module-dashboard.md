# ADR 0014 — Phase 1.6 UI Completion Before Backend Work

## Status
Accepted

## Context
The UI shell still needed three big pieces before phase 2 could begin: a proper RAG workspace, a richer settings page, and module dashboards that show more than summary cards plus a table.

## Decision
We will complete one more UI-only phase that adds:
- immediate custom tooltips for the icon sidebar,
- stronger hover behavior for light mode,
- a more distinctive `VK` brand badge,
- module-specific dashboard charts,
- a UI-only New Item modal form,
- a three-panel RAG workspace,
- a richer settings workspace with mock controls.

## Consequences
### Positive
- The remaining major UX surfaces can be reviewed before backend implementation.
- The RAG and Settings pages better reflect their actual product roles.
- Item-management flows become easier to visualize.

### Negative
- The phase-1 shell grows in complexity and will later need real data wiring.
