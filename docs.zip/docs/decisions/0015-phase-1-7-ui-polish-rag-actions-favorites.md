# ADR 0015 — Phase 1.7 UI Polish Round

## Status
Accepted

## Context
The previous UI shell still needed refinement in navigation polish, action menus, RAG usability, and item-detail flows.

## Decision
We will perform another UI-only patch to:
- strengthen borders and hover states,
- enlarge the RAG workspace,
- add better chat item actions,
- preserve scroll position during pagination,
- restore shared RAG settings inside Settings,
- add favorites previews for module pages,
- and provide detail/edit modal samples.

## Consequences
### Positive
- The user can review more realistic item-management flows before backend integration.
- RAG and settings surfaces are closer to the intended product shape.
- Module pages now better communicate favorites and module-specific metrics.

### Negative
- The frontend shell continues to grow in complexity before the data layer is wired.
