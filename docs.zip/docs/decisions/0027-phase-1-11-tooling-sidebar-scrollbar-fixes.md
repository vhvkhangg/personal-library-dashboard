# 0027 — Phase 1.11 tooling, sidebar, and scrollbar fixes

## Status
Accepted

## Context
The latest Phase 1.11 review identified build/lint regressions and small shell polish issues:

- TypeScript rejected `ignoreDeprecations: "6.0"` in `tsconfig.json`.
- ESLint 9 produced circular config failures with the previous compatibility-based config.
- New React hook lint rules flagged synchronous `setState` calls inside effects.
- The chart preview mutated a local render variable during render.
- Light-mode scrollbars needed stronger contrast.
- The module/content separator line created an extra-looking segment on the module sidebar side.
- The protected PIN dialog needed tighter label positioning.

## Decision

Apply a targeted patch only to the affected files.

## Changes

- Remove deprecated `baseUrl` and invalid `ignoreDeprecations` from `apps/web/tsconfig.json`.
- Keep Next.js mandatory/suggested values:
  - `jsx: "react-jsx"`
  - `.next/dev/types/**/*.ts` in `include`
- Replace the ESLint compatibility config with the flat `eslint-config-next` exports.
- Remove mount-state effects from portal/menu components and rely on event-time portal rendering.
- Remove synchronous position updates from dropdown/menu effects.
- Rewrite the donut chart segment calculation so it does not mutate render-local variables.
- Use a lazy theme initializer instead of setting theme state inside an effect.
- Darken light-mode scrollbar track/thumb colors.
- Restrict the top horizontal shell divider to the content side when a module sidebar is present.
- Move the PIN label slightly upward and keep the PIN modal centered.

## Notes

The Turbopack messages about persisting or compaction conflicts are development-cache warnings, not application logic errors. If they appear repeatedly, stop duplicate dev servers, remove `apps/web/.next`, and restart the dev server.
