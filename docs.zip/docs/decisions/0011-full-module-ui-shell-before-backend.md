# 0011 — Complete Full Module UI Shell Before Backend Features

## Status

Accepted

## Context

The user wants the phase 1 interface reviewed and adjusted before starting auth, tags, storage, or RAG backend work. The app has many modules, and the navigation model needs to be validated early.

## Decision

Complete a dark-first UI shell for all planned modules before implementing backend features.

The shell includes:

- icon sidebar
- module-specific menu sidebar
- collapsed menu for Dashboard, RAG, and Settings
- full route placeholders for module pages
- semantic table/list surface
- dark-first dashboard surfaces
- custom rows-per-page control
- fixed active/hover design states

## Alternatives Considered

1. Start backend auth immediately.
2. Only style the current placeholder pages.
3. Build full CRUD UI per module now.

Auth is deferred because visual structure still needs approval. Styling only current pages would leave module navigation unresolved. Full CRUD UI is too early because data model and backend APIs are not implemented.

## Consequences

The user can review the whole app shell before backend work starts. Later backend phases can connect data without repeatedly restructuring layout/navigation.

## Follow-ups

After approval, start Phase 2 Auth with JWT, owner bootstrap, and NSFW unlock session rules.
