# 0023 — Phase 1.11 runtime and UI polish

## Status
Accepted

## Context
The follow-up review found several issues in the Phase 1.11 UI shell:

- TypeScript errors in RAG workspace, row actions, and typed Next.js links.
- ESLint circular-config failure during `pnpm --filter @pld/web lint`.
- Turbopack development-cache messages such as `Persisting failed` / `Compaction failed`.
- Status dropdowns clipped near the bottom of item tables.
- Avatar preview overlay did not fully cover the viewport and still showed helper text.
- The RAG workspace VK chip did not match the sidebar VK mark.
- The header search control needed a command-palette preview.

## Decision
Apply a narrow patch that only touches affected UI/runtime files.

## Changes

### RAG workspace
- Use the same static bordered VK mark style as the sidebar logo.
- Type the citation/benchmark tab model explicitly to avoid tuple inference errors.
- Keep total cited sources compact.

### Data table
- Render status dropdown menus through a portal with fixed viewport positioning.
- Auto-place status dropdown menus above the trigger when rows are near the bottom.
- Keep status colors by state: `Active`, `Draft`, and `Archived`.
- Enlarge avatar preview by roughly 50%.
- Remove the avatar-preview helper sentence.
- Raise the avatar-preview overlay layer and use full dynamic viewport coverage.

### Row actions
- Type row action metadata explicitly so `danger` is a valid optional property.

### Navigation
- Cast typed Next.js route strings for `Link` usage in the generated navigation shell.

### Header search
- Convert the search button into a client-side command palette trigger.
- Add a sample command palette with navigation and creation actions.
- Support `Ctrl + K` / `Cmd + K` and `Esc`.

### ESLint
- Replace the web ESLint config with a flat-compatible Next.js config using `FlatCompat`.
- Keep `.next`, `node_modules`, `out`, and build artifacts ignored.

## Notes
The Turbopack `Persisting failed` / `Compaction failed` messages are development-cache concurrency warnings, not application UI code errors. If they persist after this patch, clear `.next` before restarting dev:

```powershell
Remove-Item -Recurse -Force apps\web\.next
pnpm --filter @pld/web dev
```

