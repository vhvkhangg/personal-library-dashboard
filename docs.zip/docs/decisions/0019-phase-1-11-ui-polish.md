# 0019 — Phase 1.11 UI polish

## Status
Accepted

## Context

Phase 1.10 exposed several UI issues in the dark-first dashboard shell: table footer dropdown clipping, pagination not staying anchored at the footer, oversized RAG settings, duplicated media progress overlays, and inconsistent modal header alignment.

## Decision

Apply a focused Phase 1.11 polish patch that keeps the existing UI-only architecture while refining the interaction details before backend integration.

## Changes

- Move RAG settings into the center RAG conversation column and keep the left/right RAG panels at the previous balanced widths.
- Make the table footer dropdown render above the footer without clipping.
- Keep the table footer/pagination near the viewport bottom when changing pages.
- Align the `View details` modal header with the `Edit item` modal header.
- Widen the non-Information/non-Ideaverse Tags block in item detail modals.
- Remove duplicated media overlay controls from the image surface and remove the extra frame/progress overlay.
- Keep image zoom controls only in the bottom control bar.
- Differentiate `Columns` as a blue utility action and `Export` as a green primary export action.
- Add media/watch preview panels to Series, NSFW Comic, NSFW Image, NSFW Video, Convert, Manga, Manhua, Manhwa, Novel, and Book.

## Consequences

- Phase 1 remains UI-only; no persistence or backend behavior is added.
- The affected module pages now better communicate future media/reader behavior.
- The data table shell has more deliberate overflow behavior because footer dropdowns must not be clipped.
