# 0024 — Phase 1.11 header, login, and overlay polish

## Status
Accepted

## Context
The follow-up UI review focused on the app shell, command palette, protected access surfaces, and overlay behavior. The requested changes stay in Phase 1 UI-only scope and do not add backend authentication or real persistence.

## Changes

- Add an app icon so the browser tab no longer shows the generic document icon.
- Extend the header separator line so it reaches the vertical border between the icon sidebar and module sidebar.
- Keep the icon sidebar vertical separator visually continuous from the top of the viewport.
- Remove the command palette footer copy and add `Open Ideaverse` to the Navigate group.
- Add a `/login` page with:
  - username/email/phone input,
  - password input,
  - UI-only sign-in action.
- Convert the header `H` protected-mode button into a PIN modal preview.
- Adjust avatar preview modal sizing and overlay coverage.
- Improve table status dropdown positioning for bottom rows and favorites rows.
- Prevent row action menus from flashing at an initial off-target position by calculating their position before opening.
- Preserve the current UI-only behavior: these screens are previews for later backend/JWT/PIN work.

## Notes

The terminal messages `Persisting failed: Another write batch or compaction is already active` and `Compaction failed: Another write batch or compaction is already active` are treated as local dev-cache/runtime noise rather than product UI behavior. If they persist, stop duplicate dev servers and clear the local `.next` cache before restarting the frontend.
