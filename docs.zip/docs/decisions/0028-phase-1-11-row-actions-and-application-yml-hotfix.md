# 0028 — Phase 1.11 row actions and application.yml hotfix

## Status
Accepted

## Context

The latest verification found a runtime/typecheck crash in `RowActionsMenu` because a stale `mounted` variable was still used around the delete confirmation portal.

The backend `application.yml` also produced IDE warnings:

- a map key under `spring.jpa.properties` used nested YAML instead of bracket notation,
- `app.*` was a custom prefix without configuration metadata,
- `spring.flyway.*` may appear unknown if Flyway is not present on the API classpath.

## Changes

- Removed the undefined `mounted` guard from `RowActionsMenu`.
- Kept the delete confirmation portal guarded by `confirmDeleteOpen`.
- Rewrote Hibernate JPA property binding to use bracket notation:
  - `"[hibernate.format_sql]": true`
- Added Spring Boot additional configuration metadata for:
  - `app.storage.local-root`
  - `app.obsidian.vault-path`
  - `app.rag.base-url`

## Notes

`spring.flyway.*` is a valid Spring Boot configuration prefix when Flyway is on the API classpath. If the IDE still marks it as unknown, add/check Flyway dependencies in the API `pom.xml` rather than changing the YAML key.
