# Documentation Index

This directory contains architecture notes, development phase notes, and decision records for `personal-library-dashboard`.

## Architecture

- [Overview](architecture/overview.md)
- [Repository Layout](architecture/repository-layout.md)
- [Modules](architecture/modules.md)
- [UI Guidelines](architecture/ui-guidelines.md)
- [Data Model](architecture/data-model.md)
- [Storage](architecture/storage.md)
- [Obsidian Sync](architecture/obsidian-sync.md)
- [Local RAG/OCR](architecture/rag-local.md)
- [Security/Auth](architecture/security-auth.md)
- [Testing and Verification](architecture/testing-and-verification.md)

## Development Phases

- [Phase Roadmap](development/phase/phase-roadmap.md)
- [Phase 1 — Scaffold](development/phase/phase-1-scaffold.md)
- [Phase 1.1 — UI Shell Refinement](development/phase/phase-1-1-ui-refinement.md)
- [Phase 1.2 — Dark-First Navigation and Table Refinement](development/phase/phase-1-2-dark-navigation-table-refinement.md)
- [Tooling](development/tooling.md)
- [Docs Fix Checklist](development/fix-checklist.md)

## Architecture Decision Records

- [0001 — Deployment: Docker Desktop on Windows desktop host](decisions/0001-deployment-docker-desktop-windows.md)
- [0002 — Auth: single-user JWT](decisions/0002-auth-jwt-single-user.md)
- [0003 — Storage: local large media + Google Drive-capable abstraction](decisions/0003-storage-local-plus-google-drive.md)
- [0004 — Obsidian vault as Ideaverse source of truth](decisions/0004-obsidian-vault-source-of-truth.md)
- [0005 — Offline local RAG/OCR/LLM](decisions/0005-local-rag-ocr-llm.md)
- [0006 — Hybrid relational + JSONB data model](decisions/0006-hybrid-relational-jsonb-tags.md)
- [0007 — Dashboard/list UI style](decisions/0007-dashboard-table-ui-style.md)
- [0008 — MVP implementation order](decisions/0008-mvp-order.md)
- [0009 — UI shell refinement for Phase 1.1](decisions/0009-ui-shell-refinement-phase-1-1.md)
- [0010 — Dark-first navigation and table refinement](decisions/0010-dark-first-navigation-table-refinement.md)
