# Phase 1.7 — UI Polish for RAG, actions, favorites, and details

## Goal
Address the latest review round before moving further into backend work.

## Scope
- Make the `VK` logo static.
- Strengthen outline borders and hover states.
- Improve table action dropdown behavior.
- Add rename/pin/delete actions to RAG chat items.
- Remove unnecessary RAG header buttons.
- Expand RAG workspace proportions.
- Replace reranker toggle with a dropdown mode selector.
- Preserve scroll position during pagination changes.
- Restore RAG-related settings in the Settings workspace.
- Add more charts to dashboard and module dashboards.
- Show sample favorite rows with yellow stars.
- Add a favorites table to module pages, excluding Dashboard, Ideaverse, RAG, and Settings.
- Add UI-only view-details and edit-item modal samples.
