# Phase 1.10 — Table, Media, and Ideaverse Polish

## Goal

Apply the next UI review round before backend implementation begins.

## Decisions

- Descriptions belong under the item title in the list table, not as a separate table column.
- Filters should be grouped into one explicit filter surface.
- Export should present only practical export formats: JSON, CSV, Excel.
- Media modules should show controls that match their content type.
- Ideaverse submodules should feel like vault/file browsing, not generic item tables.

## Scope

Frontend-only changes for layout, mock interactions, and preview components.
