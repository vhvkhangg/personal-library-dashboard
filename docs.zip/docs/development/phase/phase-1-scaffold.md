# Phase 1 — Scaffold

## Purpose

Phase 1 creates the first runnable skeleton of the project. It intentionally avoids real business logic so the baseline can be verified before adding auth, data models, storage, or RAG.

## Included Areas

### Root

- `package.json`
- `pnpm-workspace.yaml`
- `turbo.json`
- `.env.example`
- `compose.yaml`
- `compose.override.yaml`

### Frontend

- `apps/web`
- Next.js 16 App Router
- English UI labels
- double-sidebar shell
- dashboard placeholder
- module placeholder pages
- shared UI component structure

### Backend

- `services/api`
- Spring Boot 4.0.6
- Java 25
- Maven
- base package: `com.vhvkhangg.personallibrarydashboard`
- health endpoint: `/api/health`
- Actuator health endpoint
- Flyway migration location
- modular monolith package placeholders

### RAG Service

- `services/rag`
- Python package: `pld_rag`
- FastAPI app shell
- health endpoints
- ingestion/query placeholders
- placeholder directories for OCR, parsing, embeddings, retrieval, reranking, generation, and evaluation

### Infrastructure

- PostgreSQL + pgvector container
- local Docker Compose setup
- PowerShell helper scripts

## Verification Commands

From repository root:

```powershell
pnpm install
```

Start PostgreSQL:

```powershell
docker compose up -d postgres
docker compose ps
```

Run backend:

```powershell
mvn -f services\api\pom.xml spring-boot:run
```

Expected backend checks:

```powershell
curl http://localhost:8080/api/health
curl http://localhost:8080/actuator/health
```

Run frontend:

```powershell
pnpm --filter @pld/web dev
```

Expected frontend URL:

```txt
http://localhost:3000
```

Run RAG service:

```powershell
uv --directory services/rag sync --extra dev
uv --directory services/rag run uvicorn pld_rag.api.app:create_app --factory --reload --host 0.0.0.0 --port 8000
```

Expected RAG checks:

```powershell
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

## Known Limitations

- Auth is not implemented yet.
- The dashboard uses placeholder data.
- Tables do not call real APIs yet.
- RAG endpoints are placeholders.
- Obsidian sync is not implemented yet.
- Google Drive storage is not implemented yet.
