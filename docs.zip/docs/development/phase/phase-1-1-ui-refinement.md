# Phase 1.1 — UI Shell Refinement

## Purpose

Phase 1.1 improves the scaffold UI before deeper feature work begins. This is intentionally done before auth and data integration because layout-level changes are cheaper now than later.

## User Feedback Addressed

The user requested:

1. Table headers.
2. Rows-per-page control with options `10`, `20`, `30`, `40`, `50`.
3. Favorite star before the row number.
4. One extra useful column to reduce empty spacing.
5. `Ctrl K` changed to `Ctrl + K`.
6. Light/dark toggle beside the NSFW `H` button.
7. Settings separated from normal content modules.
8. More global dashboard content while keeping the phase clean.
9. Clearer sidebar active state.

## Decisions

### Table/List Shell

Use these phase-1 columns:

```txt
Favorite + # | Item | Type | Tag | Updated | Rating | Actions
```

Rationale:

- `Updated` is useful across all modules.
- Domain-specific columns such as `World Setting` for Fiction should be added later per module.
- Favorite belongs visually near the row number, not as a separate major domain column.

Rows per page options:

```txt
10 / 20 / 30 / 40 / 50
```

Default:

```txt
10
```

### Header

Use:

```txt
Ctrl + K
```

Add a theme toggle beside the NSFW button:

```txt
[Theme icon] [H]
```

### Sidebar

Settings is a system item, not a content module.

Layout:

```txt
Library
- Dashboard
- Fiction
- Film
- Media
- F&B
- Information
- NSFW
- Ideaverse
- Documents

System
- Settings
```

Icon sidebar also moves Settings to the bottom.

### Global Dashboard

Keep phase 1.1 clean, not overloaded.

Panels:

- Summary cards
  - Total Items
  - Favorites
  - Recently Updated
  - Storage Used
- Items by Module
- Rating Distribution
- Recent Updates
- Storage Overview
- Top Tags

Later phases may make the dashboard denser once real data exists.

## Files Changed

Frontend files:

```txt
apps/web/src/app/globals.css
apps/web/src/app/layout.tsx
apps/web/src/app/(dashboard)/dashboard/page.tsx
apps/web/src/components/providers/theme-provider.tsx
apps/web/src/components/layout/app-shell.tsx
apps/web/src/components/layout/app-header.tsx
apps/web/src/components/layout/theme-toggle.tsx
apps/web/src/components/layout/nsfw-toggle.tsx
apps/web/src/components/layout/icon-sidebar.tsx
apps/web/src/components/layout/menu-sidebar.tsx
apps/web/src/components/ui/button.tsx
apps/web/src/components/data-table/data-table-shell.tsx
apps/web/src/components/dashboard/summary-card.tsx
apps/web/src/components/dashboard/mini-bar-chart.tsx
apps/web/src/components/dashboard/recent-updates.tsx
apps/web/src/components/dashboard/storage-overview.tsx
apps/web/src/components/dashboard/top-tags.tsx
apps/web/src/lib/routes.ts
```

Documentation files:

```txt
docs/README.md
docs/development/phase-roadmap.md
docs/development/phase-1-scaffold.md
docs/development/phase-1-1-ui-refinement.md
docs/decisions/0009-ui-shell-refinement-phase-1-1.md
```

## Verification

Run:

```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```

Manual checks:

- Dashboard renders.
- Theme toggle switches between light and dark.
- Header shows `Ctrl + K`.
- Table has headers.
- Table has favorite star before row number.
- Rows-per-page selector contains `10`, `20`, `30`, `40`, `50`.
- Settings appears under System and at the bottom of icon sidebar.
- Active sidebar state is visible.

## Deferred

- Real data fetching.
- Real command palette behavior.
- Persisted theme preference beyond `next-themes` default handling.
- Real favorite mutation.
- Real pagination state.
- Module-specific columns such as Fiction `World Setting`.
