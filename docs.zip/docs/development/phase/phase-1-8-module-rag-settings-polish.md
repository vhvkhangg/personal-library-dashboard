# Phase 1.8 — Module, RAG, Settings, Charts, and Modal Polish

## Goal
Address the latest UI review and make the phase-1 frontend shell closer to the intended product behavior before backend work.

## Scope
- Hide unnecessary domain columns for Health, Technology, and Miscellaneous.
- Improve the Item Details modal layout and add more summary cards.
- Add a module tag panel with a `New Tag` action.
- Restrict New/Edit Item tag selection to existing tags in the UI mock.
- Restore the previous `VK` logo treatment while keeping it static.
- Refine RAG Workspace message identity, upload preview, Mode control, and Benchmark clarity.
- Remove RAG/OCR-specific cards from Settings and add general app/data settings.
- Add donut, column, line, and area chart samples.
- Add media preview/player shells to Movie, Image, Video, and Music pages.
- Add no-domain column behavior for selected Information submodules.
- Reduce hydration mismatch risk in the icon sidebar and document the `.next` cleanup step.

## Out of scope
- Real backend data.
- Real media playback.
- Real file upload.
- Persisted tags.
- Actual charting library integration.
