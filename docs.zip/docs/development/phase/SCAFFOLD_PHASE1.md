# Scaffold Phase 1

Phase 1 creates the first runnable skeleton:

- root monorepo files
- Next.js 16 web shell
- Spring Boot 4.0.6 API shell
- Python FastAPI RAG shell
- Docker Compose for PostgreSQL/pgvector, optional Ollama, and service profiles

## Apply

Extract this archive into the repository root and allow overwrite when asked.

Then run:

```powershell
corepack enable
pnpm install
docker compose up -d postgres
mvn -f services/api/pom.xml spring-boot:run
uv --directory services/rag sync --extra dev
uv --directory services/rag run uvicorn pld_rag.api.app:create_app --factory --reload --host 0.0.0.0 --port 8000
pnpm --filter @pld/web dev
```

Expected URLs:

- Web: http://localhost:3000
- API health: http://localhost:8080/api/health
- API actuator health: http://localhost:8080/actuator/health
- RAG health: http://localhost:8000/health/live
