# UI Phase 1.7

## Main updates
- Static `VK` brand badge.
- Clearer borders across outline buttons and cards.
- Hover feedback for `View details` and `Edit item`.
- RAG chat row menu now includes `Rename`, `Pin chat`, and `Delete` with outside-click closing.
- RAG header action buttons removed.
- RAG page uses larger three-column proportions.
- `Enable reranker` changed to a mode dropdown.
- Table pagination keeps the same vertical position.
- Settings now includes both general settings and shared RAG settings again.
- Overall and module dashboards now have extra charts with sample data.
- Module pages now include a favorites section.
- `Movie` and `Actor` got page-specific column configurations.
- Added modal previews for `View details`, `Edit item`, and `New Item`.
