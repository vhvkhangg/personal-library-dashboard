# UI Phase 1.9 Hotfix — Routes Exports

## Problem

`routes.ts` was accidentally replaced with a different route schema during the Phase 1.9 patch. Existing layout components still import:

- `primaryNavigation`
- `systemNavigation`
- `getActiveNavigation`
- `getMenuSectionsForPath`
- `isMenuItemActive`

The replaced file did not export those symbols, so Next.js failed during build.

## Fix

Restore the expected route API in `apps/web/src/lib/routes.ts` and keep the Phase 1.9 media menu change that removes `Song` from the sidebar.
