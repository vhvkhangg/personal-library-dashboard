# UI Phase 1.5

## Summary
Phase 1.5 is the last UI-only polish pass before backend work begins.

## Key improvements
- Buttons and icon hovers use a stronger accent hover state.
- Light mode uses brighter interactive foregrounds.
- Module sidebar no longer keeps both `Dashboard` and a child page active at the same time.
- The data table is now interactive in the shell layer:
  - rows per page,
  - page 1 and page 2 preview,
  - actions dropdown.
- RAG and Settings now have dedicated workspace UIs.

## Table behavior
- `Fav` stays narrow and centered.
- `#` uses the same active pill style as selected pagination.
- `Tags` supports multiple pills per item.
- Page buttons use a gradient active state and do not add a hover style when already selected.

## Notes
The table and the workspace pages remain placeholder UIs. They are intended to validate layout direction before wiring real module data.
