# UI Phase 1.3 Notes

## Design Direction

Dark-first personal library dashboard.

The interface should feel like a focused private workstation rather than a generic admin template.

## Key Rules

- Default to dark mode.
- Use blue-violet active states for selected navigation and selected controls.
- Keep hover state related but lighter than selected state.
- Use semantic tables for list/table surfaces.
- Keep Settings and RAG as direct pages without a module menu sidebar.
- Use module-specific menus for content modules.
- Use English labels and English route paths.

## Table Structure

Generic module table columns:

```txt
Favorite | # | Item | Type | Tag | Context | Updated | Rating | Actions
```

Module-specific tables can rename `Context` later:

- Fiction: `World Setting`
- Film: `Format` or `Progress`
- Media: `Format`, `Duration`, or `Progress`
- F&B: `Cuisine`
- Ideaverse: `Vault Area`
- RAG: `Pipeline`

## Theme Implementation

Use a custom local theme provider.

Do not use `next-themes` in this phase because it injected a script tag and produced hydration mismatch warnings in the current Next.js 16/Turbopack setup.

## Known Placeholders

- Table rows are mock data.
- Cards are mock metrics.
- Menu routes are route placeholders.
- Command palette is visual only.
- NSFW toggle is visual only.
