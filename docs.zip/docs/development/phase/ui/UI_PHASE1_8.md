# UI Phase 1.8

## Highlights
- Health, Technology, and Miscellaneous tables no longer show a Domain column.
- Detail modal now uses `Item` capitalization and has a richer summary area.
- Each module table has a module tag strip and a `New Tag` button.
- New/Edit Item forms select from existing tags only.
- RAG question/answer blocks now show a `VK` identity and RAG icon.
- RAG upload button now opens a sample upload panel.
- Benchmark has clearer Citation/Benchmark tabs, per-row quality indicators, and a conclusion box.
- Settings removed RAG/OCR-specific cards and gained Data & Export plus App Maintenance sections.
- Dashboard and module dashboards include mixed chart samples.
- Movie/Image/Video/Music pages include sample preview/player panels.

## Dev note
If React still reports a hydration mismatch after applying this patch, stop the dev server, delete `apps/web/.next`, and run the dev server again. The previous error included stale rendered classes for `IconSidebar` and `MenuSidebar`, which is consistent with cached build output after repeated overwrite patches.
