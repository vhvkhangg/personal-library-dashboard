# UI Phase 1.9

## Summary

This patch focuses on table UX polish, media preview refinements, and RAG workspace clarity.

## Included updates

- Removed module-level charts from subpages and kept them only on the global dashboard and per-module dashboard pages.
- Added `+ New Item`, a `New Tag` creation sample, and demo popovers for `Columns` and `Export`.
- Added date range filters to module table toolbars.
- Added `Avatar` and `Description` columns to item tables, with automatic avatar hiding for the Information module.
- Improved table pagination behavior so page changes keep the footer area in view.
- Improved row action menus so the final rows open upward instead of clipping.
- Refined `View details`, `Edit item`, and `New item` modals.
- Expanded media previews for movie, video, music, picture, image, and illustration, including a sample full-view modal.
- Merged Song into Music navigation and changed Music table context to `Artist`.
- Updated the RAG workspace with clearer Citation/Benchmark tabs, benchmark status icons, a chunk viewer sample, upload modal sample, and reset/save actions.
- Added custom dark scrollbar styling to better match the UI.

## Notes

- The old `/media/song` route is no longer linked from the sidebar menu.
- These screens remain UI-only placeholders and do not yet persist state.
