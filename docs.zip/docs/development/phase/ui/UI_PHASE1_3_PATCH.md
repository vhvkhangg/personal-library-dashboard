# UI Phase 1.3 Patch

Apply this patch instead of earlier UI phase 1.1 or 1.2 patches.

## Fixes

- Removes `next-themes` usage to avoid script tag and hydration mismatch warnings.
- Defaults to dark mode.
- Fixes rows-per-page dropdown color by replacing native `select` with a custom control.
- Makes `New Item` outline-style like `Columns` and `Export`.
- Splits Favorite and `#` into separate table columns.
- Reworks sidebar active/hover states using blue-violet accent styling.
- Collapses menu sidebar for Dashboard, RAG, and Settings.
- Adds module-specific menus for all content modules.
- Changes RAG icon to a notebook-style icon.
- Adds placeholder pages for all planned module menu routes.
- Adds phase docs and ADR.

## Verify

```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```
