# UI Phase 1.6

## What changed
- Fixed sidebar/menu hover states for both dark and light themes.
- Added immediate hover tooltips for icon sidebar items.
- Changed the brand badge from `PL` to `VK` with a more distinct treatment.
- Expanded module dashboards with module-specific charts and panels.
- Added a modal-style New Item form.
- Rebuilt the RAG page into a three-column workspace.
- Expanded the Settings page with more future-facing controls.

## Hydration / dev note
If the local dev server still shows stale classes or old markup, stop the dev server, delete the `.next` folder, and run `pnpm --filter @pld/web dev` again.
