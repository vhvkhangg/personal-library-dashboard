# UI Phase 1.4 Patch

## Files included
- apps/web/src/lib/routes.ts
- apps/web/src/components/layout/menu-sidebar.tsx
- apps/web/src/components/data-table/data-table-shell.tsx
- docs/development/phase/phase-1-4-navigation-table-polish.md
- docs/development/phase/ui/UI_PHASE1_4.md
- docs/decisions/0012-phase-1-4-navigation-table-polish.md

## Apply
Extract this archive into the repository root and overwrite the existing files.

## Verify
```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```
