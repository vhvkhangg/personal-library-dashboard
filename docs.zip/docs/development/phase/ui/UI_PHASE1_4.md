# UI Phase 1.4

## Summary
This patch is a focused polish pass on top of phase 1.3.

## User-approved changes
1. Remove repeated module label inside the menu sidebar.
2. Keep only the sidebar header showing the active module name.
3. Center the `Fav`, `#`, `Type`, `Tags`, domain, `Updated`, `Rating`, and `Actions` columns.
4. Keep the `Item` column left-aligned.
5. Change `Favorite` header to `Fav`.
6. Render multiple tag pills for each placeholder item.
7. Swap the RAG and Ideaverse icons.

## Notes
- Tags should support multiple values per item. In the real system this should be modeled as a many-to-many or item-to-tag relation.
- This phase remains UI-only.
