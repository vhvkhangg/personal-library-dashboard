# UI Patch Phase 1.1

Changes:
- Adds table column headers.
- Adds favorite star before row number.
- Adds `Updated` column.
- Adds rows-per-page selector with 10 / 20 / 30 / 40 / 50.
- Changes command shortcut from `Ctrl K` to `Ctrl + K`.
- Adds light/dark theme toggle beside NSFW `H`.
- Separates Settings to the bottom/system area in sidebars.
- Adds sidebar active state.
- Improves the global dashboard with clean phase-1 panels.

Apply by copying/overwriting these files into the repository root.

Then run:

```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```
