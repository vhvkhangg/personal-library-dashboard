# Phase 1.11 — RAG, table, and media polish

## Scope

This phase is a visual and interaction refinement pass over the Phase 1 UI prototype.

## Implemented

1. RAG Workspace
   - RAG settings are now scoped to the center chat column.
   - The side panels keep the previous workspace proportions.

2. Tables
   - Rows-per-page dropdown opens upward without footer clipping.
   - Pagination changes attempt to keep the user anchored at the bottom of the table.
   - `Columns` and `Export` have clearer semantic styling.

3. Detail/Edit modals
   - `View details` header alignment matches `Edit item`.
   - Tags block is wider on regular modules.

4. Media previews
   - Removed redundant overlay progress panels.
   - Removed floating zoom controls from the image surface.
   - Added preview surfaces for Series, NSFW Comic, NSFW Image, NSFW Video, Convert, Manga, Manhua, Manhwa, Novel, and Book.

## Verification checklist

Run after overwriting the patch:

```powershell
Remove-Item -Recurse -Force apps\web\.next
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```
