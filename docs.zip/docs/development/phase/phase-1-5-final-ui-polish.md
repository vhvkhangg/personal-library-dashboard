# Phase 1.5 — Final UI Polish Before Backend Work

## Goal
Polish the phase 1 UI shell so the user can review all major frontend states before moving to auth, backend, and data phases.

## Scope
- Improve hover and active states for the dark-first design.
- Improve light mode icon and button visibility.
- Fix menu sidebar active-state behavior for module dashboards versus subpages.
- Improve table alignment, tags layout, and pagination preview.
- Add a real actions dropdown preview in the table.
- Replace the generic RAG and Settings item-list pages with dedicated workspace layouts.
- Keep all new documentation inside the `docs/` folder only.

## User-approved changes
1. Brighter interactive states, especially in light mode.
2. Better hover state quality.
3. Better centered tags column.
4. `...` actions menu preview.
5. Better selected pagination style and a visible page 2 state.
6. Dedicated RAG and Settings pages.
7. Fix module submenu active-state logic.
8. Improve sidebar logo visibility.

## Out of scope
- Real data loading.
- Backend integration.
- Authentication flows.
- RAG execution.
