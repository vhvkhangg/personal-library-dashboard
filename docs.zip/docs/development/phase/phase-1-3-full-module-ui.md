# Phase 1.3 — Full Module UI Shell

## Status

Planned for immediate application.

## Purpose

Phase 1.3 keeps backend integration out of scope and focuses on completing the dark-first UI shell for all modules so the visual direction can be reviewed before auth, tags, storage, and data modeling work begin.

## Scope

This phase covers frontend UI only:

- dark-first theme without `next-themes` hydration/script issues
- stable light/dark toggle
- module-specific side menu per icon sidebar item
- collapsed menu sidebar for Dashboard, RAG, and Settings
- improved active and hover states using blue-violet accent surfaces
- semantic table structure
- fixed table alignment
- custom rows-per-page picker
- separate Favorite and `#` columns
- outline-style `New Item` button
- route placeholders for all currently planned module pages

## Non-Scope

This phase does not implement:

- authentication
- real data fetching
- backend APIs
- tag CRUD
- image viewer behavior
- Obsidian sync
- RAG ingestion/query behavior

## Verification

Run:

```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```

Then review:

- `/dashboard`
- `/fiction`
- `/fiction/convert`
- `/film`
- `/media`
- `/fnb`
- `/information`
- `/nsfw`
- `/ideaverse`
- `/documents`
- `/settings`

## Follow-up

After the user approves the UI shell, move to Phase 2 Auth.
