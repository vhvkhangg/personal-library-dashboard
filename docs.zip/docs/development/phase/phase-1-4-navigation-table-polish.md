# Phase 1.4 — Navigation and Table Polish

## Goal
Polish the phase 1 UI shell before backend work continues.

## Scope
- Remove redundant repeated section labels inside the module sidebar.
- Keep the module sidebar header (`Module` + module name).
- Center narrow table columns for better visual balance.
- Rename `Favorite` to `Fav` in the table header.
- Show multiple tags per item in placeholder rows.
- Swap the Ideaverse and RAG icons in the icon sidebar.

## Why
The earlier phase 1.3 shell already established the dark-first direction and complete module coverage. This refinement focuses on visual clarity and consistency after interactive review.

## Result
- Cleaner module sidebar.
- Better table alignment.
- More realistic tag representation.
- More intuitive icon assignment for Ideaverse and RAG.
