# Phase 1.2 — Dark-First Navigation and Table Refinement

## Purpose

Phase 1.2 fixes visual and structural issues found after testing Phase 1.1 in the browser.

The user reported:

1. Table columns and rows looked misaligned.
2. Some elements looked black even in light mode.
3. Selected sidebar/menu items were too white and should use a blue-violet active color.
4. The app should default to dark mode and polish dark mode first.
5. The secondary sidebar showed the same menu for every icon instead of module-specific menus.
6. Settings should not appear in the secondary menu because it has no sub-menu.
7. RAG/Documents should behave similarly to Settings and collapse the secondary menu.
8. The Next.js development `N` indicator covered the Settings icon.

## Decisions

### Dark-First UI

Phase 1.2 changes the design direction to dark-first.

Default theme:

```txt
dark
```

The light theme remains supported, but it is no longer the primary polish target for this phase.

### Active State Color

Selected items now use the project accent color:

```txt
blue-violet / indigo
```

This applies to:

- icon sidebar active item
- module menu active item
- active filter tab
- selected page button
- row number badge

### Table Layout

The generic table shell now uses a semantic HTML table instead of CSS grid rows.

Reason:

- table headers and cells align more reliably
- accessibility is better
- future column visibility logic becomes easier

Columns:

```txt
★ / # | Item | Type | Tag | Updated | Rating | Actions
```

### Module-Specific Secondary Sidebar

The secondary sidebar is now driven by the active primary icon.

Examples:

- Fiction shows Fiction submenus.
- Media shows Media submenus.
- NSFW shows NSFW submenus.
- Ideaverse shows Ideaverse submenus.

The secondary sidebar collapses when the active section has no meaningful sub-menu.

Collapsed sections:

- Dashboard
- RAG/Documents
- Settings

### Next.js Dev Indicator

The Next.js development indicator is disabled because it overlaps the bottom Settings icon during local development.

This does not hide runtime/build errors; it only hides the development route indicator.

## Files Changed

```txt
apps/web/next.config.ts
apps/web/src/app/globals.css
apps/web/src/app/layout.tsx
apps/web/src/app/(dashboard)/dashboard/page.tsx
apps/web/src/components/providers/theme-provider.tsx
apps/web/src/components/ui/button.tsx
apps/web/src/components/layout/app-shell.tsx
apps/web/src/components/layout/app-header.tsx
apps/web/src/components/layout/theme-toggle.tsx
apps/web/src/components/layout/nsfw-toggle.tsx
apps/web/src/components/layout/icon-sidebar.tsx
apps/web/src/components/layout/menu-sidebar.tsx
apps/web/src/components/data-table/data-table-shell.tsx
apps/web/src/components/dashboard/summary-card.tsx
apps/web/src/components/dashboard/mini-bar-chart.tsx
apps/web/src/components/dashboard/recent-updates.tsx
apps/web/src/components/dashboard/storage-overview.tsx
apps/web/src/components/dashboard/top-tags.tsx
apps/web/src/lib/routes.ts
```

## Verification

Run:

```powershell
pnpm --filter @pld/web typecheck
pnpm --filter @pld/web lint
pnpm --filter @pld/web dev
```

Manual checks:

- App starts in dark mode by default.
- Theme toggle can switch between dark and light.
- Sidebar active state is blue-violet, not white.
- Settings only appears in the icon sidebar.
- RAG/Documents route collapses the secondary sidebar.
- Fiction, Film, Media, F&B, Information, NSFW, and Ideaverse show different secondary menus.
- Table header and rows align correctly.
- Table no longer uses black surfaces in light mode.
- Next.js dev indicator no longer covers Settings.

## Deferred

- Real menu permission filtering for locked NSFW.
- Real command palette behavior.
- Real table pagination state.
- Module-specific table columns.
- Fine-tuning light mode visual polish.
