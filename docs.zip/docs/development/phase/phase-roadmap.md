# Development Phase Roadmap

## Phase 0 — Documentation and Architecture

Status: complete enough to begin scaffolding.

Outputs:

- `AGENTS.md`
- architecture docs
- ADRs
- initial repo conventions

## Phase 1 — Scaffold

Status: implemented locally.

Goal:

- create runnable project skeleton
- verify frontend, backend, RAG service, and PostgreSQL can start

## Phase 1.1 — UI Shell Refinement

Status: implemented locally.

Goal:

- improve dashboard shell
- add table headers, rows-per-page control, favorite marker, extra column
- add theme toggle
- separate Settings visually
- add global dashboard panels

## Phase 1.2 — Dark-First Navigation and Table Refinement

Status: current patch.

Goal:

- make dark mode the default
- fix table alignment with semantic table markup
- make active states blue-violet
- add module-specific secondary menus
- collapse secondary menu for Dashboard, RAG/Documents, and Settings
- disable the Next.js dev indicator that overlaps Settings

## Phase 2 — Authentication

Planned.

Scope:

- single owner bootstrap from `.env`
- JWT access token
- refresh token
- httpOnly cookies
- `/auth/login`
- `/auth/refresh`
- `/auth/logout`
- `/auth/me`
- NSFW PIN unlock session design

## Phase 3 — Tags

Planned.

Scope:

- global tags
- scoped tags
- tag CRUD
- item-tag assignment model

## Phase 4 — Image Viewer

Planned.

Scope:

- image gallery shell
- image detail viewer
- previous/next navigation
- zoom controls

## Phase 5 — Fiction

Planned.

Scope:

- Fiction module data model
- first real item table
- module-specific columns

## Phase 6 — Storage

Planned.

Scope:

- local storage provider
- storage metadata
- Google Drive provider abstraction

## Phase 7 — Export

Planned.

Scope:

- CSV export
- Excel export
- filtered list export
- WPS Office compatibility

## Phase 8 — Obsidian Read/Index

Planned.

Scope:

- external vault path
- manual sync
- Markdown file indexing
- frontmatter parsing
- read-only web view first

## Phase 9 — Video/Music Player

Planned.

Scope:

- browser-supported playback
- seek controls
- speed controls
- progress tracking

## Phase 10 — Local RAG

Planned.

Scope:

- document ingestion
- PaddleOCR/Tesseract/Docling integration
- BGE-M3 embeddings
- sparse + dense hybrid retrieval
- CrossEncoder reranking
- Ollama local LLM answering
