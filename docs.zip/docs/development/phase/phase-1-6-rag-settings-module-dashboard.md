# Phase 1.6 — RAG Workspace, Settings Expansion, and Module Dashboard Polish

## Goal
Finish the remaining major phase-1 UI shells before backend phases start.

## Scope
- Fix remaining navigation-state and hover-state issues.
- Replace delayed browser-title behavior with immediate custom sidebar tooltips.
- Redesign the RAG page into a dedicated three-panel workspace.
- Expand Settings into a richer settings workspace with editable mock controls.
- Add richer dashboard content for each module, not only tables.
- Provide a UI-only New Item form.
- Refresh the logo treatment.

## Notes
This phase is still frontend shell work only. No backend behavior is wired yet.
