# 0021 — Phase 1.11 follow-up: RAG workspace actions and detail-modal tag polish

## Status
Accepted

## Context
The phase 1.11 UI shell needed another refinement pass focused on the local RAG workspace and detail-modal presentation.
The latest review requested better action density in the left workspace rail, a cleaner central chat surface, a benchmark conclusion block, a smaller Ideaverse Core dropdown button, and a consistent tag header box in item detail views.

## Decision
Apply the following UI refinements:

1. **Ideaverse sidebar Core button**
   - Keep the Core section as a dropdown.
   - Make the Core trigger visually match the Dashboard button height and compactness.

2. **RAG workspace left rail**
   - Add per-chat overflow actions: `Pin`, `Rename`, `Delete`.
   - Change uploaded-document top actions to icon-only controls.
   - Add an icon-only upload button and a red delete-all button.
   - Add per-document overflow actions: `Pin`, `Delete`.

3. **RAG workspace center chat panel**
   - Remove the decorative “Local workspace preview” hero block.
   - Render the user question on the right and the answer on the left.
   - Add copy actions on both message types.
   - Add regenerate on answer messages.
   - Simplify inline citation chips to numeric markers only.
   - Simplify the composer by removing the inner bordered input panel and the extra copy button.
   - Place upload at the bottom-left and send at the bottom-right of the composer.

4. **RAG workspace right inspector**
   - Extend the benchmark view with a sample conclusion card below the metric list.

5. **Item detail modal**
   - Standardize the header layout so `View details` sits directly above the item title.
   - Use the same bordered tag box style for Information items as other modules.
   - Keep summary, description, and note areas in the content body.

6. **Ideaverse vault pages**
   - Remove the obsolete descriptive prop usage for the vault preview page headers.

## Consequences
- The RAG workspace now feels more like a practical document QA tool and less like a placeholder demo.
- Detail views are more consistent across modules, especially for Information.
- Sidebar and vault navigation stay consistent with prior phase 1.11 refinements while improving clarity.
