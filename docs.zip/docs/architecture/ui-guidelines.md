# UI Guidelines

## Visual Direction

The UI should look like a modern dark-first SaaS/admin dashboard with a media-library and knowledge-base feel.

Reference traits:

- dark mode is the primary polish target for early phases
- light mode remains supported but can be refined later
- subtle borders
- rounded cards
- table/list hybrid pages
- semantic table shells for tabular data
- large readable rows
- pill badges
- strong toolbar
- search and filters near the top
- pagination
- column visibility control
- export button
- action menu with `...`
- blue-violet/indigo active states

## App Shell

### Header

Header contains:

- global search / command palette
- theme toggle
- NSFW toggle button using the letter `H`
- optional future actions

Global search should search across allowed modules based on current NSFW state.

### Sidebar

Use double sidebar when the active module has sub-navigation:

1. Icon sidebar:
   - Dashboard
   - Fiction
   - Film
   - Media
   - F&B
   - Information
   - NSFW when unlocked/visible
   - Ideaverse
   - RAG/Documents
   - Settings
2. Module sidebar:
   - module-specific navigation only

Collapse the module sidebar when the active section has no detail menu.

Collapsed sections for now:

- Dashboard
- RAG/Documents
- Settings

Active states should use the project accent color, not plain white.

### Main Content Pattern

Use this pattern for list pages:

```txt
Breadcrumb
Title
Subtitle
Primary action button

Filter tabs

Toolbar:
- Search input
- Category/type filters
- Columns button
- Export button

Table/List:
- favorite + row number
- title + secondary text
- category/type
- tags
- updated date
- rating
- actions

Footer:
- result count
- rows per page
- pagination
```

## Dashboard Cards

Global dashboard:

- 4 cards.

Category/module dashboard:

- 8 cards.
- 2 rows.
- 4 cards per row.

## List Row by Module

### Fiction Row

```txt
Cover/Icon | Title + author/description | Type | Tags/Genres | Rating | Status/Progress | Updated | Actions
```

### Film Row

```txt
Poster/Icon | Title + actor/description | Movie/Series | Tags | Rating | Watched progress | Updated | Actions
```

### Media Row

```txt
Thumbnail | Title + metadata | Type | Tags | Duration/Progress | Storage | Updated | Actions
```

### F&B Row

```txt
Icon/Image | Name + note | Food/Beverage | Tags | Rating | Tried? | Updated | Actions
```

### Ideaverse Row

```txt
Doc icon | Title + file path | Type | Tags | Status | Last synced | Updated | Actions
```

### Documents/RAG Row

```txt
File icon | Filename + parsed summary | Type | RAG status | Attached to | Updated | Actions
```

## States

Every page must support:

- loading state
- empty state
- error state
- no search results state
- permission/NSFW locked state if relevant

## Accessibility

Rules:

- all icon buttons must have accessible names
- keyboard navigation required for command palette
- do not use color alone for status
- maintain readable contrast
- table rows must be navigable/clickable without ambiguity
- use semantic tables for tabular data
- focus states must be visible in dark mode
